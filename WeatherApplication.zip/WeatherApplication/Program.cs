﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

class Program
{
    static async Task Main(string[] args)
    {
        Dictionary<string, (decimal, decimal)> cityData = CityGetData();
        Console.Write("Enter the name of the city:- ");
        string cityName = Console.ReadLine();
		if (cityData.TryGetValue(cityName, out var coordinates))
        {
            decimal latitude = coordinates.Item1;
            decimal longitude = coordinates.Item2;

            string apiRequest = $"https://api.open-meteo.com/v1/forecast?latitude={latitude}&longitude={longitude}&current_weather=true";

            using (HttpClient client = new HttpClient())
            {
                try
                {
                    HttpResponseMessage response = await client.GetAsync(apiRequest);

                    if (response.IsSuccessStatusCode)
                    {
                        string json = await response.Content.ReadAsStringAsync();
                        Console.WriteLine(json);
                    }
                    else
                    {
                        Console.WriteLine("The weather information retrieval failed.");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"An error occurred: {ex.Message}");
                }
            }
        }
        else
        {
            Console.WriteLine("The data of the city required is not present.");
        }
    }

    static Dictionary<string, (decimal, decimal)> CityGetData()
    {
        var cityData = new Dictionary<string, (decimal, decimal)>();
        string filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "cities.csv");
        using (StreamReader reader = new StreamReader(filePath))
        {
            reader.ReadLine();
            while (!reader.EndOfStream)
            {
                string line = reader.ReadLine();
                string[] values = line.Split(',');
                string cityName = values[0];
                decimal latitude = Convert.ToDecimal(values[1]);
                decimal longitude = Convert.ToDecimal(values[2]);

                cityData[cityName] = (latitude, longitude);
            }
        }
        return cityData;
    }
}

